package util

func Max(a , b int)int{
	if(a > b){
		return a
	}
	return b
}